package com.example.resistencias;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    Button BLACK, BROWN, RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE, GRAY, WHITE, SILVER, GOLD, BANDA1, BANDA2, BANDA3, BANDA4;
    public static String EXTRA_MESSAGE =

            "com.example.android.resistencias.extra.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BLACK = findViewById(R.id.IDBlack);
        BLACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#000000"));
                    banda1=0;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#000000"));
                    banda2=0;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#000000"));
                    banda3=0;
                }
                Ocultarbotones();
            }
        });
        BROWN = findViewById(R.id.IDBrown);
        BROWN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#694D4D"));
                    banda1=1;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#694D4D"));
                    banda2=1;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#694D4D"));
                    banda3=1;
                }
                else if (numbanda == 4)
                {
                    BANDA4.setBackgroundColor(Color.parseColor("#694D4D"));
                    banda4=1;
                }
                Ocultarbotones();
            }
        });


        RED = (Button)findViewById(R.id.IDRed);
        RED.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#E92213"));
                    banda1=2;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#E92213"));
                    banda2=2;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#E92213"));
                    banda3=2;
                }
                else if (numbanda == 4)
                {
                    BANDA4.setBackgroundColor(Color.parseColor("#E92213"));
                    banda4=2;
                }
                Ocultarbotones();
            }
        });

        ORANGE = (Button)findViewById(R.id.IDOrange);
        ORANGE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#FF9800"));
                    banda1=3;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#FF9800"));
                    banda2=3;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#FF9800"));
                    banda3=3;
                }
                Ocultarbotones();
            }
        });

        YELLOW = (Button)findViewById(R.id.IDYellow);
        YELLOW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#FFEB3B"));
                    banda1=4;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#FFEB3B"));
                    banda2=4;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#FFEB3B"));
                    banda3=4;
                }
                Ocultarbotones();
            }
        });

        GREEN = (Button)findViewById(R.id.IDGreen);
        GREEN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#4CAF50"));
                    banda1=5;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#4CAF50"));
                    banda2=5;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#4CAF50"));
                    banda3=5;
                }
                else if (numbanda == 4)
                {
                    BANDA4.setBackgroundColor(Color.parseColor("#4CAF50"));
                    banda4=5;
                }
                Ocultarbotones();
            }
        });

        BLUE = (Button)findViewById(R.id.IDBlue);
        BLUE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#2196F3"));
                    banda1=6;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#2196F3"));
                    banda2=6;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#2196F3"));
                    banda3=6;
                }
                else if (numbanda == 4)
                {
                    BANDA4.setBackgroundColor(Color.parseColor("#2196F3"));
                    banda4=6;
                }
                Ocultarbotones();
            }
        });

        PURPLE = (Button)findViewById(R.id.IDPurple);
        PURPLE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numbanda == 1)
                {
                    BANDA1.setBackgroundColor(Color.parseColor("#673AB7"));
                    banda1=7;
                }
                else if (numbanda == 2)
                {
                    BANDA2.setBackgroundColor(Color.parseColor("#673AB7"));
                    banda2=7;
                }
                else if (numbanda == 3)
                {
                    BANDA3.setBackgroundColor(Color.parseColor("#673AB7"));
                    banda3=7;
                }
                else if (numbanda == 4)
                {
                    BANDA4.setBackgroundColor(Color.parseColor("#673AB7"));
                    banda4=7;
                }
                Ocultarbotones();
            }
        });


        GRAY = (Button)findViewById(R.id.IDGray);
        WHITE = (Button)findViewById(R.id.IDWhite);
        SILVER  = (Button)findViewById(R.id.IDSilver);
        GOLD = (Button)findViewById(R.id.IDGold);

        BANDA1 = (Button)findViewById(R.id.IDBand1);
        BANDA2 = (Button)findViewById(R.id.IDBand2);
        BANDA3 = (Button)findViewById(R.id.IDBand3);
        BANDA4 = (Button)findViewById(R.id.IDBand4);
        Ocultarbotones();

    }
int numbanda;
    int banda1 = 99 , banda2 = 99, banda3 = 99, banda4;
    public void Banda1(View view)
    {
        Ocultarbotones();
        Mostrarbotones();
        numbanda = 1;
    }
    public void Banda2(View view)
    {
        Ocultarbotones();
        Mostrarbotones();
        numbanda = 2;
    }
    public void Banda3(View view)
    {
        Ocultarbotones();
        Mostrarbotones();
        numbanda = 3;
    }
    public void Banda4(View view)
    {
        Ocultarbotones();

        SILVER.setVisibility(View.VISIBLE);
        GOLD.setVisibility(View.VISIBLE);
        BROWN.setVisibility(View.VISIBLE);
        RED.setVisibility(View.VISIBLE);
        GREEN.setVisibility(View.VISIBLE);
        BLUE.setVisibility(View.VISIBLE);
        PURPLE.setVisibility(View.VISIBLE);
        numbanda = 4;
    }
    public void Ocultarbotones()
    {
        BLACK.setVisibility(View.INVISIBLE);
        BROWN.setVisibility(View.INVISIBLE);
        RED.setVisibility(View.INVISIBLE);
        ORANGE.setVisibility(View.INVISIBLE);
        YELLOW.setVisibility(View.INVISIBLE);
        GREEN.setVisibility(View.INVISIBLE);
        BLUE.setVisibility(View.INVISIBLE);
        PURPLE.setVisibility(View.INVISIBLE);
        GRAY.setVisibility(View.INVISIBLE);
        WHITE.setVisibility(View.INVISIBLE);
        GOLD.setVisibility(View.INVISIBLE);
        SILVER.setVisibility(View.INVISIBLE);
    }

    public void Mostrarbotones()
    {
        BLACK.setVisibility(View.VISIBLE);
        BROWN.setVisibility(View.VISIBLE);
        RED.setVisibility(View.VISIBLE);
        ORANGE.setVisibility(View.VISIBLE);
        YELLOW.setVisibility(View.VISIBLE);
        GREEN.setVisibility(View.VISIBLE);
        BLUE.setVisibility(View.VISIBLE);
        PURPLE.setVisibility(View.VISIBLE);
        GRAY.setVisibility(View.VISIBLE);
        WHITE.setVisibility(View.VISIBLE);
    }

    public void LeGray(View view) {
        if (numbanda == 1)
        {
            BANDA1.setBackgroundColor(Color.parseColor("#665E5E"));
            banda1=8;
        }
        else if (numbanda == 2)
        {
            BANDA2.setBackgroundColor(Color.parseColor("#665E5E"));
            banda2=8;
        }
        else if (numbanda == 3)
        {
            BANDA3.setBackgroundColor(Color.parseColor("#665E5E"));
            banda3=8;
        }
        Ocultarbotones();
    }

    public void LeWhite(View view) {
        if (numbanda == 1)
        {
            BANDA1.setBackgroundColor(Color.parseColor("#FFFFFF"));
            banda1=9;
        }
        else if (numbanda == 2)
        {
            BANDA2.setBackgroundColor(Color.parseColor("#FFFFFF"));
            banda2=9;
        }
        else if (numbanda == 3)
        {
            BANDA3.setBackgroundColor(Color.parseColor("#FFFFFF"));
            banda3=9;
        }
        Ocultarbotones();
    }

    public void LeSilver(View view) {
            BANDA4.setBackgroundColor(Color.parseColor("#B6B4AE"));
            banda4 = 10;
        Ocultarbotones();
    }
    public void LeGold(View view) {
            BANDA4.setBackgroundColor(Color.parseColor("#C09611"));
            banda4=11;
        Ocultarbotones();
    }
        public void LeCalcula(View view) {
        if(banda1==99)
            Toast.makeText(MainActivity.this, "Selecciona el color de la banda 1", Toast.LENGTH_SHORT).show();
        else if(banda2==99)
            Toast.makeText(MainActivity.this, "Selecciona el color de la banda 2", Toast.LENGTH_SHORT).show();
        else if(banda3==99)
            Toast.makeText(MainActivity.this, "Selecciona el color de la banda 3", Toast.LENGTH_SHORT).show();
        else
        {
            Intent intent = new Intent(this, Secondactivity.class);
            intent.putExtra("banda1", banda1);
            intent.putExtra("banda2", banda2);
            intent.putExtra("banda3", banda3);
            intent.putExtra("banda4", banda4);
            startActivity(intent);
        }
    }
}
