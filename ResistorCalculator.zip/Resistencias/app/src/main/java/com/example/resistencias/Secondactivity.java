package com.example.resistencias;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Secondactivity extends AppCompatActivity {
    TextView RESU, TOLE, TOLE2, TOLEMENOR, TOLEMAYOR;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondactivity);
        Intent intent = getIntent();


        RESU = findViewById(R.id.IDResultado);
        TOLE = findViewById(R.id.IDResultadoTol);
        TOLE2 = findViewById(R.id.IDResultadoTol2);
        TOLEMENOR = findViewById(R.id.IDTolemenor);
        TOLEMAYOR = findViewById(R.id.IDTolemayor);

        int res;
        String Resultado, Tolerancia="No Especificado";
        String ToleResultado ="No Especificado";
        String Tolemayor ="No Especificado";
        String Tolemenor = "No Especificado";

        double Tole=0;
        double tolemay = 0;
        double tolemeni = 0;
        Bundle datos = this.getIntent().getExtras();
        int banda1 = datos.getInt("banda1");
        int banda2 = datos.getInt("banda2");
        int banda3 = datos.getInt("banda3");
        int banda4 = datos.getInt("banda4");

        res = (banda1 * 10) + banda2;
        switch (banda3) {
            case 0:
                res = res * 1;
                break;
            case 1:
                res = res * 10;
                break;
            case 2:
                res = res * 100;
                break;
            case 3:
                res = res * 1000;
                break;
            case 4:
                res = res * 10000;
                break;
            case 5:
                res = res * 100000;
                break;
            case 6:
                res = res * 1000000;
                break;
            case 7:
                res = res * 10000000;
                break;
            case 8:
                res = res * 100000000;
                break;
        }
        if(banda3==9){
            Resultado = "" + res;
            Resultado = Resultado + "000000000";
        }
        else
        Resultado = "" + res;
        Resultado = Resultado + " Ω";
        RESU.setText(Resultado);
        switch (banda4)
        {
            case 1:
                Tole = res * .01;
                Tolerancia = "+/- 1%";
                break;
            case 2:
                Tole = res * .02;
                Tolerancia = "+/- 2%";
                break;
            case 5:
                Tole = res* .005;
                Tolerancia = "+/- 0.5%";
                break;
            case 6:
                Tole = res* .0025;
                Tolerancia = "+/- 0.25%";
                break;
            case 7:
                Tole = res* .001;
                Tolerancia = "+/- 0.10%";
                break;
            case 8:
                Tole = res* .005;
                Tolerancia = "+/- 0.05%";
                break;
            case 10:
                Tole = res* .05;
                Tolerancia = "+/- 5%";
                break;
            case 11:
                Tole = res* .10;
                Tolerancia = "+/- 10%";
                break;
        }
        ToleResultado= "" + Tole;
        ToleResultado = ToleResultado+ " Ω";
        TOLE.setText(Tolerancia);
        TOLE2.setText(ToleResultado);
        tolemay = res+Tole;
        tolemeni = res-Tole;

        Tolemayor = "" + tolemay;
        Tolemenor= "" + tolemeni;

        TOLEMENOR.setText(Tolemenor);
        TOLEMAYOR.setText(Tolemayor);

    }
}
