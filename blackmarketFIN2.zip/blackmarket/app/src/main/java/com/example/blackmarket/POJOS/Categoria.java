package com.example.blackmarket.POJOS;

import java.util.ArrayList;

public class Categoria {
    String nombre;
    int id;
   // ArrayList<Producto> productosEjemplo = new ArrayList<>();

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
