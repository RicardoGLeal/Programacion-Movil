package com.example.blackmarket.POJOS;

public class Prueba {
    int x;

    public int isX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
}
